<script type="text/javascript" src="/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/jquery-rails-2.2.1/vendor/assets/javascripts/jquery.js"></script>;
<script type="text/javascript" src="/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/jquery-rails-2.2.1/vendor/assets/javascripts/jquery_ujs.js"></script>;
<script type="text/javascript" src="/Users/mfung/Workspace/dogbrigade-v2/.jhw-cache/coffee_script/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/turbolinks-1.0.0/lib/assets/javascripts/turbolinks.js.coffee.js"></script>
            <script type="text/javascript">window.CSTF['turbolinks.js.coffee.js'] = '/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/turbolinks-1.0.0/lib/assets/javascripts/turbolinks.js.coffee';</script>;
<script type="text/javascript" src="/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/twitter-bootstrap-rails-2.2.6/vendor/assets/javascripts/twitter/bootstrap/bootstrap-transition.js"></script>;
<script type="text/javascript" src="/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/twitter-bootstrap-rails-2.2.6/vendor/assets/javascripts/twitter/bootstrap/bootstrap-alert.js"></script>;
<script type="text/javascript" src="/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/twitter-bootstrap-rails-2.2.6/vendor/assets/javascripts/twitter/bootstrap/bootstrap-modal.js"></script>;
<script type="text/javascript" src="/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/twitter-bootstrap-rails-2.2.6/vendor/assets/javascripts/twitter/bootstrap/bootstrap-dropdown.js"></script>;
<script type="text/javascript" src="/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/twitter-bootstrap-rails-2.2.6/vendor/assets/javascripts/twitter/bootstrap/bootstrap-scrollspy.js"></script>;
<script type="text/javascript" src="/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/twitter-bootstrap-rails-2.2.6/vendor/assets/javascripts/twitter/bootstrap/bootstrap-tab.js"></script>;
<script type="text/javascript" src="/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/twitter-bootstrap-rails-2.2.6/vendor/assets/javascripts/twitter/bootstrap/bootstrap-tooltip.js"></script>;
<script type="text/javascript" src="/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/twitter-bootstrap-rails-2.2.6/vendor/assets/javascripts/twitter/bootstrap/bootstrap-popover.js"></script>;
<script type="text/javascript" src="/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/twitter-bootstrap-rails-2.2.6/vendor/assets/javascripts/twitter/bootstrap/bootstrap-button.js"></script>;
<script type="text/javascript" src="/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/twitter-bootstrap-rails-2.2.6/vendor/assets/javascripts/twitter/bootstrap/bootstrap-collapse.js"></script>;
<script type="text/javascript" src="/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/twitter-bootstrap-rails-2.2.6/vendor/assets/javascripts/twitter/bootstrap/bootstrap-carousel.js"></script>;
<script type="text/javascript" src="/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/twitter-bootstrap-rails-2.2.6/vendor/assets/javascripts/twitter/bootstrap/bootstrap-typeahead.js"></script>;
<script type="text/javascript" src="/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/twitter-bootstrap-rails-2.2.6/vendor/assets/javascripts/twitter/bootstrap/bootstrap-affix.js"></script>;
<script type="text/javascript" src="/Users/mfung/.rvm/gems/ruby-1.9.3-p194@dogbrigade-v2/gems/twitter-bootstrap-rails-2.2.6/vendor/assets/javascripts/twitter/bootstrap.js"></script>;
<script type="text/javascript" src="/Users/mfung/Workspace/dogbrigade-v2/.jhw-cache/coffee_script/Users/mfung/Workspace/dogbrigade-v2/app/assets/javascripts/bootstrap.js.coffee.js"></script>
            <script type="text/javascript">window.CSTF['bootstrap.js.coffee.js'] = '/Users/mfung/Workspace/dogbrigade-v2/app/assets/javascripts/bootstrap.js.coffee';</script>;
<script type="text/javascript" src="/Users/mfung/Workspace/dogbrigade-v2/.jhw-cache/coffee_script/Users/mfung/Workspace/dogbrigade-v2/app/assets/javascripts/pages.js.coffee.js"></script>
            <script type="text/javascript">window.CSTF['pages.js.coffee.js'] = '/Users/mfung/Workspace/dogbrigade-v2/app/assets/javascripts/pages.js.coffee';</script>;
<script type="text/javascript" src="/Users/mfung/Workspace/dogbrigade-v2/.jhw-cache/coffee_script/Users/mfung/Workspace/dogbrigade-v2/app/assets/javascripts/search.js.coffee.js"></script>
            <script type="text/javascript">window.CSTF['search.js.coffee.js'] = '/Users/mfung/Workspace/dogbrigade-v2/app/assets/javascripts/search.js.coffee';</script>;
<script type="text/javascript" src="/Users/mfung/Workspace/dogbrigade-v2/.jhw-cache/coffee_script/Users/mfung/Workspace/dogbrigade-v2/app/assets/javascripts/sessions.js.coffee.js"></script>
            <script type="text/javascript">window.CSTF['sessions.js.coffee.js'] = '/Users/mfung/Workspace/dogbrigade-v2/app/assets/javascripts/sessions.js.coffee';</script>;
<script type="text/javascript" src="/Users/mfung/Workspace/dogbrigade-v2/.jhw-cache/coffee_script/Users/mfung/Workspace/dogbrigade-v2/app/assets/javascripts/users.js.coffee.js"></script>
            <script type="text/javascript">window.CSTF['users.js.coffee.js'] = '/Users/mfung/Workspace/dogbrigade-v2/app/assets/javascripts/users.js.coffee';</script>;
<script type="text/javascript" src="/Users/mfung/Workspace/dogbrigade-v2/app/assets/javascripts/application.js"></script>;
